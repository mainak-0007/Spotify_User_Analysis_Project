import pandas as pd
import numpy as np
from datetime import datetime

LAMBDA = 0.01
USE_LOG = True

# Step 1: Read and perform an initial check of the file
user_df = pd.read_csv("user_features_final_cleaned.csv")

feature_df = pd.read_pickle("feature_df.pkl")

print("Number of user records:", len(user_df))
print("Feature table shape:", feature_df.shape)
print("Feature_df index sample:", feature_df.index[:5])

# Resolve potential formatting issues with track_id
user_df["track_id"] = user_df["track_id"].str.strip().str.lower()
feature_df.index = feature_df.index.str.strip().str.lower()

# Step2: Align track id
# Ensure track_id types match to avoid mismatches
user_df["track_id"] = user_df["track_id"].astype(str)
feature_df.index = feature_df.index.map(str)

common_ids = set(user_df["track_id"]).intersection(set(feature_df.index))
user_df = user_df[user_df["track_id"].isin(common_ids)].reset_index(drop=True)

print("User records after alignment:", len(user_df))
print("Number of common tracks:", len(common_ids))

# Step 3: Process the time field and calculate days_since
user_df["last_play_time"] = pd.to_datetime(user_df["last_play_time"], errors="coerce")

user_df["last_play_time"] = user_df["last_play_time"].fillna(
    user_df["last_play_time"].min() - pd.Timedelta(days=3650)
)

T_ref = user_df["last_play_time"].max()
user_df["days_since"] = (T_ref - user_df["last_play_time"]).dt.days.astype(int)

# Step 4：Weight design
# Apply smoothing to 'play_count'
if USE_LOG:
    user_df["pc_smooth"] = np.log1p(user_df["play_count"])
else:
    user_df["pc_smooth"] = user_df["play_count"].astype(float)

# Compute the exponential time-decay weight
user_df["recency_w"] = np.exp(-LAMBDA * user_df["days_since"].astype(float))

# Compute the final weight
user_df["weight"] = user_df["pc_smooth"] * user_df["recency_w"]


# Step 5: Map behavioral data to corresponding feature analysis
id_to_idx = {tid: i for i, tid in enumerate(feature_df.index)}
user_df["feat_idx"] = user_df["track_id"].map(id_to_idx)
item_matrix = feature_df.values
user_item_vectors = item_matrix[user_df["feat_idx"].values]

# Step 6: Calculate the weighted average to obtain user_profile
# Get the weight array (order must match the first dimension of user_item_vectors)
weights = user_df["weight"].values.astype(float)

# Safety check: if all weights are zero, avoid division by zero
weight_sum = weights.sum()
if weight_sum == 0:
    weights = np.ones_like(weights)
    weight_sum = weights.sum()

# Compute the weighted average:
user_profile = np.dot(weights, user_item_vectors) / weight_sum

# Perform L2 normalization for cosine similarity comparisons
user_profile_norm = (
    user_profile / np.linalg.norm(user_profile)
    if np.linalg.norm(user_profile) != 0
    else user_profile
)

np.save("user_profile.npy", user_profile)
np.save("user_profile_norm.npy", user_profile_norm)
