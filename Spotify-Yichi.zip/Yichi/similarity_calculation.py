import numpy as np
import pandas as pd
from sklearn.preprocessing import normalize

# 1) Load standardized user profiles and song feature files
user_profile = np.load("user_profile_norm.npy", allow_pickle=True)
item_matrix = np.load("item_matrix.npy")
feature_df = pd.read_pickle("feature_df.pkl")

# 2) Check whether the dimensions are consistent
print("user_profile shape:", user_profile.shape)
print("item_matrix shape:", item_matrix.shape)

# 3) Standardize the item matrix and compute cosine similarity
item_matrix_norm = normalize(item_matrix, axis=1)
sims = item_matrix_norm.dot(user_profile)

# Package similarity scores into a DataFrame, using track_id as the index for easy sorting and filtering.
scores_df = pd.DataFrame(
    {"track_id": feature_df.index.astype(str), "score": sims}
).set_index("track_id")

# Insert repair code (unify track_id type)
tracks_meta = pd.read_csv("songs_cleaned.csv")
scores_df = scores_df.reset_index()
scores_df["track_id"] = scores_df["track_id"].astype(str)
tracks_meta["track_id"] = tracks_meta["track_id"].astype(str).str.strip()

# Merge
tracks_meta = pd.read_csv("songs_cleaned.csv")
scores_df = scores_df.merge(tracks_meta, on="track_id", how="left")

print(scores_df.head(10))

# 4) Check the outcome
print("Similarity stats:")
print(scores_df["score"].describe())

# 5）Save the file
scores_df.to_csv("all_item_similarity_scores.csv")
