import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import io

# Suppress warnings
warnings.filterwarnings('ignore')

# Constants
# NOTE: The CSV file MUST be in the same folder as this script.
FILE_PATH = "/Users/abhibardhan/Data Analytics Project/FInal Code and Graphs/user_song_merged_cleaned_data.csv"
FEATURES = [
    'danceability', 'energy', 'acousticness', 'valence',
    'speechiness', 'instrumentalness', 'liveness', 'tempo',
    'loudness', 'duration_ms', 'popularity', 'play_count'
]
AUDIO_FEATURES = FEATURES[:-1]

# --- Helper functions ---

def image_to_bytes(plt_object, filename=None):
    """Saves a matplotlib figure to a file and closes it correctly."""
    buf = io.BytesIO()
    # Save the figure to both the buffer and the file
    plt_object.savefig(buf, format='png', bbox_inches='tight')
    if filename:
        plt_object.savefig(filename, bbox_inches='tight')
    buf.seek(0)
    # Use plt.close() which is the robust way to close a Figure object.
    plt.close(plt_object) 
    return buf

def prepare_data(df):
    """Loads and prepares the data for analysis."""
    required_cols_original = FEATURES + ['artist', 'track_name', 'track_genre']
    df_original = df[df.columns.intersection(required_cols_original)].copy()
    
    df_analysis = df_original[FEATURES].copy()
    
    # Coerce features to numeric
    for col in FEATURES:
        if col in df_analysis.columns:
            if df_analysis[col].dtype == object or not pd.api.types.is_numeric_dtype(df_analysis[col]):
                df_analysis[col] = pd.to_numeric(df_analysis[col], errors='coerce')
        else:
            raise ValueError(f"Required feature column '{col}' not found in data.")

    # Drop rows with NaN values
    valid_indices = df_analysis.dropna(subset=FEATURES).index
    df_analysis = df_analysis.loc[valid_indices].copy()
    df_original = df.loc[valid_indices].copy()
        
    print(f"Data prepared. Rows used for modeling: {len(df_analysis)}")
    return df_original, df_analysis.copy()


# --- 1. Data Segmentation and Favorite Songs/Genres ---
def get_favorites_segmentation(df):
    """Identifies top 10 favorites (artists, songs, genres) and generates bar chart images."""
    print("\n--- 1. Data Segmentation & Favorite Songs/Genres ---")

    # 1a. Top 10 Favorite Artists 
    top_artists = df.groupby('artist')['play_count'].sum().nlargest(10).sort_values(ascending=True)
    
    fig_artist = plt.figure(figsize=(10, 6))
    sns.barplot(x=top_artists.values, y=top_artists.index, palette='viridis')
    plt.title('Top 10 Favorite Artists by Total Play Count', fontsize=14)
    plt.xlabel('Total Play Count')
    plt.ylabel('Artist')
    plt.tight_layout()
    image_to_bytes(fig_artist, filename="top_10_artists.png")
    print("Top 10 Artist Bar Chart generated (top_10_artists.png).")

    # 1b. Top 10 Favorite Songs (unique tracks)
    # Re-read df to ensure full columns are available for merging track name and artist
    try:
        df_temp = pd.read_csv(FILE_PATH)
        df_temp = df_temp.loc[df.index].copy()
    except Exception:
        df_temp = df.copy() 

    df_temp['song_artist'] = df_temp['track_name'].astype(str) + ' - ' + df_temp['artist'].astype(str)
    top_songs = df_temp.groupby('song_artist')['play_count'].sum().nlargest(10).sort_values(ascending=True)
    
    fig_song = plt.figure(figsize=(10, 6))
    sns.barplot(x=top_songs.values, y=top_songs.index, palette='plasma')
    plt.title('Top 10 Most Played Songs (Unique Tracks)', fontsize=14)
    plt.xlabel('Play Count')
    plt.ylabel('Song Name - Artist')
    plt.tight_layout()
    image_to_bytes(fig_song, filename="top_10_songs.png")
    print("Top 10 Song Bar Chart generated (top_10_songs.png).")

    # 1c. Top 10 Favorite Genres
    if 'track_genre' in df.columns:
        top_genres = df.groupby('track_genre')['play_count'].sum().nlargest(10).sort_values(ascending=True)
        
        fig_genre = plt.figure(figsize=(10, 6))
        sns.barplot(x=top_genres.values, y=top_genres.index, palette='cubehelix')
        plt.title('Top 10 Favorite Genres by Total Play Count', fontsize=14)
        plt.xlabel('Total Play Count')
        plt.ylabel('Genre')
        plt.tight_layout()
        image_to_bytes(fig_genre, filename="top_10_genres.png")
        print("Top 10 Genre Bar Chart generated (top_10_genres.png).")
    else:
        print("Skipping Genre Analysis: 'track_genre' column is missing or cleaned out.")


# --- 2. Visualizations ---
def generate_visualizations(df_features):
    """Generates histograms and scatter plots with best line fit."""
    print("\n--- 2. Generating Visualizations ---")
    
    # 2a. Histograms for distribution analysis
    cols = 3
    rows = int(np.ceil(len(FEATURES) / cols))

    fig_hist, axes_hist = plt.subplots(rows, cols, figsize=(15, 4 * rows))
    axes_hist = axes_hist.flatten()
    for i, col in enumerate(FEATURES):
        sns.histplot(df_features[col], kde=True, ax=axes_hist[i])
        axes_hist[i].set_title(f'Distribution of {col.replace("_", " ").title()}', fontsize=12)
        axes_hist[i].set_xlabel(col.replace("_", " ").title())
        axes_hist[i].set_ylabel('Frequency')
    
    for j in range(i + 1, len(axes_hist)):
        fig_hist.delaxes(axes_hist[j])

    plt.tight_layout()
    image_to_bytes(fig_hist, filename="feature_histograms.png")
    print("Histograms generated (feature_histograms.png).")

    # 2b. Scatter Plots with Best Line Fit
    feature_list_no_play_count = AUDIO_FEATURES
    cols = 4 
    rows = int(np.ceil(len(feature_list_no_play_count) / cols))

    fig_scatter, axes_scatter = plt.subplots(rows, cols, figsize=(18, 4 * rows))
    axes_scatter = axes_scatter.flatten()
    
    for i, col in enumerate(feature_list_no_play_count):
        sns.regplot(x=df_features[col], y=df_features['play_count'], 
                    scatter_kws={'alpha':0.4, 's':10}, 
                    line_kws={'color':'red', 'linestyle':'--'}, 
                    ax=axes_scatter[i])
        axes_scatter[i].set_title(f'{col.replace("_", " ").title()} vs. Play Count', fontsize=12)
        axes_scatter[i].set_xlabel(col.replace("_", " ").title())
        axes_scatter[i].set_ylabel('Play Count')
        axes_scatter[i].grid(True, linestyle='--', alpha=0.6)

    for j in range(i + 1, len(axes_scatter)):
        fig_scatter.delaxes(axes_scatter[j])
        
    plt.tight_layout()
    image_to_bytes(fig_scatter, filename="feature_scatterplots_with_fit.png")
    print("Scatter Plots with Regression Line generated (feature_scatterplots_with_fit.png).")


# --- Main Execution Block ---
def run_analysis():
    print("--- Starting User Behavior Analysis Script ---")
    
    try:
        df = pd.read_csv(FILE_PATH)
    except FileNotFoundError:
        print(f"\nFATAL ERROR: CSV file not found.")
        print(f"Please ensure '{FILE_PATH}' is in the SAME directory as this script.")
        return

    try:
        df_original, df_analysis = prepare_data(df)
    except ValueError as e:
        print(f"\nFATAL ERROR: Data Preparation Failed. Check your CSV column names.")
        print(f"Error details: {e}")
        return

    # Run all required analysis steps
    get_favorites_segmentation(df_original)
    generate_visualizations(df_analysis)
    
    print("\n*** ALL OPERATIONS COMPLETE. ***")
    print("Please check your current directory for the generated .png image files.")

if __name__ == "__main__":
    run_analysis()