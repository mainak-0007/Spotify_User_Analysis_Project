import csv, time, requests
from datetime import datetime, timezone

API_KEY = ""
USER = "Rocket_25"
START_DATE = "2023-01-01"
END_DATE = "2025-10-01"
RAW_FILE = "user_raw.csv"


def parse_date_to_ts(s, is_end=False):
    dt = datetime.fromisoformat(s) if len(s) > 10 else datetime.strptime(s, "%Y-%m-%d")
    if is_end and len(s) <= 10:
        dt = datetime(dt.year, dt.month, dt.day, 23, 59, 59)
    return int(dt.replace(tzinfo=timezone.utc).timestamp())


def safe_json(r):
    try:
        return r.json()
    except Exception:
        print("Failed to parse JSON:", r.text[:200])
        return None


def get_recent_tracks(user, api_key, from_ts, to_ts, page=1, limit=200):
    url = "https://ws.audioscrobbler.com/2.0/"
    params = {
        "method": "user.getRecentTracks",
        "user": user,
        "api_key": api_key,
        "format": "json",
        "limit": limit,
        "page": page,
        "from": from_ts,
        "to": to_ts,
    }
    r = requests.get(url, params=params, timeout=15)
    return safe_json(r) if r.status_code == 200 else None


def fetch_raw_data(user, api_key, start_date, end_date):
    from_ts = parse_date_to_ts(start_date)
    to_ts = parse_date_to_ts(end_date, True)
    events, page = [], 1
    while True:
        data = get_recent_tracks(user, api_key, from_ts, to_ts, page)
        if not data or "recenttracks" not in data:
            break
        tracks = data["recenttracks"].get("track", [])
        if isinstance(tracks, dict):
            tracks = [tracks]
        if not tracks:
            break
        for t in tracks:
            d = t.get("date", {}).get("uts")
            if not d:
                continue
            events.append(
                [
                    t.get("name", "").strip(),
                    t.get("artist", {}).get("#text", "").strip(),
                    datetime.utcfromtimestamp(int(d)).strftime("%Y-%m-%d %H:%M:%S"),
                ]
            )
        total_pages = int(data["recenttracks"].get("@attr", {}).get("totalPages", 1))
        print(f"Fetched page {page}/{total_pages}, total {len(events)} records.")
        if page >= total_pages:
            break
        page += 1
        time.sleep(0.2)
    with open(RAW_FILE, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["track_name", "artist", "timestamp"])
        writer.writerows(events)
    print(f"Saved {len(events)} rows to {RAW_FILE}")


if __name__ == "__main__":
    fetch_raw_data(USER, API_KEY, START_DATE, END_DATE)
