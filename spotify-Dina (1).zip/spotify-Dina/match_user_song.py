#!/usr/bin/env python3
import re
from pathlib import Path
import pandas as pd

# config
USER_FILE = "user_aggregated.csv"
SONG_FILE = "song_data.csv"
OUTPUT_FILE = "user_song_merged_exact.csv"
REPORT_FILE = "merge_report_exact.txt"

def read_csv_safe(path):
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{path} not found")
    try:
        return pd.read_csv(p, sep=None, engine="python", encoding="utf-8")
    except Exception:
        return pd.read_csv(p, engine="python", on_bad_lines="skip", encoding="utf-8")

def clean_artist(s):
    if pd.isna(s):
        return ""
    s = str(s).strip()
    if ";" in s:
        s = s.split(";")[0]
    elif "," in s:
        s = s.split(",")[0]
    return s.lower().strip()

def clean_text(s):
    if pd.isna(s):
        return ""
    s = str(s).lower().strip()
    s = re.sub(r"\(.*?\)|\[.*?\]|（.*?）", "", s)
    s = re.sub(r"feat\..*|ft\..*|featuring.*", "", s)
    s = re.sub(r"[^\w\s]", " ", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()

def ensure_artist_column(song_df):
    # if dataset uses 'artists' field, extract first artist into 'artist'
    if "artist" not in song_df.columns and "artists" in song_df.columns:
        song_df["artist"] = song_df["artists"].fillna("").apply(
            lambda s: str(s).split(";")[0].split(",")[0].strip()
        )

def main():
    user = read_csv_safe(USER_FILE)
    song = read_csv_safe(SONG_FILE)

    if "track_name" not in song.columns:
        raise ValueError("song_data must contain 'track_name' column")

    ensure_artist_column(song)

    # normalize and build keys
    user["track_name_clean"] = user["track_name"].fillna("").apply(clean_text)
    user["artist_clean"] = user["artist"].fillna("").apply(clean_artist)
    song["track_name_clean"] = song["track_name"].fillna("").apply(clean_text)
    song["artist_clean"] = song["artist"].fillna("").apply(clean_artist) if "artist" in song.columns else ""

    user["key"] = user["track_name_clean"] + " - " + user["artist_clean"]
    song["key"] = song["track_name_clean"] + " - " + song["artist_clean"]

    # deduplicate song keys
    if song["key"].duplicated().any():
        song = song.drop_duplicates(subset=["key"], keep="first")

    # exact join on key -> bring track_id
    merged = pd.merge(user, song[["key", "track_id"]], on="key", how="left")
    merged["matched_id"] = merged["track_id"]
    merged["match_method"] = merged["track_id"].notna().map(lambda x: "exact" if x else "no_match")
    merged["match_score"] = merged["track_id"].notna().map(lambda x: 100 if x else 0)

    total = len(merged)
    exact_count = merged["matched_id"].notna().sum()

    # attach all song features for matched rows only
    merged = pd.merge(
        merged,
        song,
        how="left",
        left_on="matched_id",
        right_on="track_id",
        suffixes=("", "_song")
    )

    # prepare output columns: user cols, match info, then all song columns
    user_cols = [c for c in ["track_name", "artist", "play_count", "last_play_time"] if c in merged.columns]
    match_cols = ["matched_id", "match_method", "match_score"]
    song_cols = [c for c in song.columns if c not in user_cols + match_cols]
    out_cols = user_cols + match_cols + song_cols

    merged[out_cols].to_csv(OUTPUT_FILE, index=False, encoding="utf-8")

    # write report with only exact match stats and examples
    with open(REPORT_FILE, "w", encoding="utf-8") as f:
        f.write("Exact Match Report\n")
        f.write("=" * 40 + "\n")
        f.write(f"Total user tracks: {total}\n")
        f.write(f"Exact matches: {exact_count}\n")
        f.write(f"Match rate: {exact_count / total * 100:.2f}%\n\n")

        if exact_count > 0:
            f.write("Exact match examples (up to 20):\n")
            examples = merged[merged["match_method"] == "exact"].head(20)
            for _, r in examples.iterrows():
                f.write(f"- {r.get('track_name','')} — {r.get('artist','')} -> {r.get('matched_id')}\n")
        else:
            f.write("No exact matches found.\n")

    print(f"Saved merged CSV: {OUTPUT_FILE}")
    print(f"Saved report: {REPORT_FILE}")

    # save exact-matched subset
    exact_only = merged[merged["match_method"].astype(str).str.lower() == "exact"]
    exact_only.to_csv("user_features_final.csv", index=False, encoding="utf-8")

if __name__ == "__main__":
    main()
