import csv
from collections import defaultdict
from datetime import datetime

RAW_FILE = "user_raw.csv"
AGG_FILE = "user_aggregated.csv"

def aggregate_with_last_play(raw_file, output_file):
    """
    Aggregate raw listening history into play counts and last play time per track.
    Expected input CSV columns: track_name, artist, timestamp
    """
    agg = defaultdict(lambda: {"count": 0, "last_time": None})

    with open(raw_file, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["track_name"].strip()
            artist = row["artist"].strip()
            ts = row.get("timestamp", "").strip()

            try:
                play_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
            except Exception:
                play_time = None

            key = (name.lower(), artist.lower())
            agg[key]["track_name"] = name
            agg[key]["artist"] = artist
            agg[key]["count"] += 1

            # keep the latest play time
            if play_time:
                if not agg[key]["last_time"] or play_time > agg[key]["last_time"]:
                    agg[key]["last_time"] = play_time

    with open(output_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["track_name", "artist", "play_count", "last_play_time"])
        for _, v in agg.items():
            last_play = v["last_time"].strftime("%Y-%m-%d %H:%M:%S") if v["last_time"] else ""
            writer.writerow([v["track_name"], v["artist"], v["count"], last_play])

    print(f"Aggregated {len(agg)} unique tracks to {output_file}")

if __name__ == "__main__":
    aggregate_with_last_play(RAW_FILE, AGG_FILE)
